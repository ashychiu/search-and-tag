#### Description

Frontend Project - Student Profiles with Responsive Design

#### Tech stack

React, SASS

## install command

npm install

## run command

npm start

## port

3000

## see it live

https://ashleychiu-hatchways.netlify.app/
